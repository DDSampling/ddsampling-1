package ddsamplingOnline;

/**
 * 
 * @author ldiop
 *
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.ModelFactory;


public class DDSamplingRDF {
	private Integer matPondSize = 0;
	public static BufferedWriter printerAvecBuffer; 
	public static Hashtable<String, List<BigDecimal>> matricePonderation = new Hashtable<String, List<BigDecimal>>();
	public static String endpointDBp="http://dbpedia.org/sparql";
	public static String endpointWD="https://query.wikidata.org/sparql";
	public static String endpointYAGO="https://linkeddata1.calcul.u-psud.fr/sparql";
	public static List<List<BigDecimal>> matriceCnk;
	public static String requeteWiki="";
	public static Hashtable<String, String> keyRequetWiki = new Hashtable<String, String>();
		
	public DDSamplingRDF(Hashtable<String, String> myArgs,boolean defautlParam) throws NumberFormatException, Exception {
		double start = System.currentTimeMillis();	
		String superClass; //  "Organisation"
		String directory = "InputMatrix/";
		new File(directory).mkdir();
		Integer maxLength =0, minLength =0, M;//Integer.parseInt(args[1]);
		Integer N;//Integer.parseInt(args[2]);
		String bdd, utility;
		
		if(!myArgs.containsKey("sampleSize"))
			myArgs.put("sampleSize","1000");
		if(!myArgs.containsKey("utility"))
			myArgs.put("utility","Freq");
		if(!myArgs.containsKey("dataset"))
			myArgs.put("dataset","DW");
		if(!myArgs.containsKey("maxLength"))
			myArgs.put("maxLength","3");
		if(!myArgs.containsKey("class")) {
			myArgs.put("class","RaceTrack");
			myArgs.put("dataset","DW");
		}
		
		superClass = myArgs.get("class");
		N = Integer.parseInt(myArgs.get("sampleSize"));
		utility = myArgs.get("utility");
		bdd = myArgs.get("dataset");
		M = Integer.parseInt(myArgs.get("maxLength"));
		System.out.println("DDSapmling on "+superClass+" data ...");
		

		if(defautlParam) {
			System.out.println("Running with default parameters : \n\tClass : "+superClass+
				"\n\tUtility : "+utility+"\n\tSample size : "+N+"\n\tDatasets : DBpedia + Wikidata"
				+"\n\tMax length : "+M);
		}else {
			System.out.println("Running with parameters : \n\tClass : "+superClass+
					"\n\tUtility : "+utility+"\n\tSample size : "+N+"\n\tDatasets : "+bdd
					+"\n\tMax length : "+M);
		}
		

		BufferedReader lecteurAvecBuffer = null;
		try{
			lecteurAvecBuffer = new BufferedReader(new FileReader(directory+"matPond_"+superClass+".TXT"));
			String ligne = null;
			while ((ligne = lecteurAvecBuffer.readLine()) != null){
				String [] values = ligne.replace("[", "").replace("]", "").split(" ; ");
				String key = values[0];
				String[] vals = values[1].split(", ");
				List<BigDecimal> mat = new ArrayList<BigDecimal>();
				if(bdd.contains("D"))
					mat.add(new BigDecimal(vals[0]));
				if(bdd.contains("W")) {
					if(vals.length==2)
						mat.add(new BigDecimal(vals[1]));
					else
						mat.add(BigDecimal.ZERO);
				}
				if(mat.size()==0) {
					System.out.println("Invalide input dataset "+vals[0]+" "+vals[1]);
					System.exit(1);
				}
		        maxLength = Math.max(maxLength, mat.get(0).add(mat.get(1)).intValue());
		        minLength = Math.min(minLength, mat.get(0).add(mat.get(1)).intValue());
				matricePonderation.put(key, mat);
			}
			//System.out.println("Total number of entities : "+matricePonderation.size());
		}
		catch(FileNotFoundException exc){
			Integer size=0;
			String rDBpedia="", rWikidata="";
			size = -1; Integer offs=0, offset=10000;
			while(matricePonderation.size() - size!=0) { 
				size = matricePonderation.size();
				rDBpedia=""+ 
					"	select ?s ?l (count(distinct ?p ) as ?count) where {"+
			        "	?s ?p ?o . "+
			        "	{"+
			        "	select distinct ?s ?l where{ "+
			        "	?s <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> ?c ; <http://www.w3.org/2002/07/owl#sameAs> ?l ."+
			        "	?c <http://www.w3.org/2000/01/rdf-schema#subClassOf> <http://dbpedia.org/ontology/"+superClass+">."+
			        "	?s <http://www.w3.org/2002/07/owl#sameAs> ?l"+
			        "	filter(STRSTARTS(STR(?l),\"http://www.wikidata\"))"+
			        "	} LIMIT "+offset+" OFFSET "+offs.toString()+
			        "	} "+
			        "} group by ?s ?l";

				SparqlSizeOf data = new SparqlSizeOf(rDBpedia, endpointDBp);
				try {
					data.execute();
					
					rWikidata= "SELECT * WHERE { "
	            		+	"   SERVICE <" + endpointWD + "> { "
						+	"		SELECT ?item (count(distinct ?p) as ?count) WHERE {"
	            		+	"			VALUES (?item) {"+requeteWiki+"}"
	            		+	"			?item ?p ?o."
	            		+ 	"		} group by ?item"
	        			+   " 	}"
	        			+	"}"; 
					Query query = QueryFactory.create(rWikidata);
					Integer x=0; String[] keyWiki=null;
			        try (QueryExecution qexec = QueryExecutionFactory.create(query, ModelFactory.createDefaultModel())) {
			        	ResultSet resultSet = qexec.execSelect() ;
			            while (resultSet.hasNext()) {
							QuerySolution qs = resultSet.nextSolution();
							x=qs.getLiteral("count").getInt();
							keyWiki=qs.getResource("item").toString().toString().split("/");
							List<BigDecimal> values = matricePonderation.get(keyRequetWiki.get(keyWiki[keyWiki.length-1]));
					        values.add(new BigDecimal(x));
					        matricePonderation.put(keyRequetWiki.get(keyWiki[keyWiki.length-1]), values);
					        maxLength = Math.max(maxLength, values.get(0).add(values.get(1)).intValue());
					        minLength = Math.min(minLength, values.get(0).add(values.get(1)).intValue());
						}
			        }catch(Exception e){}
					//System.out.println("Wiki");
										
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				requeteWiki="";
				keyRequetWiki = new Hashtable<String, String>();
				offs+=offset;
				System.out.println(offs);
			}
			//System.exit(1);
			BufferedWriter matPonderation = null;
			String matPond="";
			try{
				matPonderation = new BufferedWriter(
						new FileWriter(directory+"matPond_"+superClass+".TXT", true));
				for(String instance:matricePonderation.keySet()) {
					matPond = instance+" ; "+matricePonderation.get(instance).toString()+"\n";
					try {
						matPonderation.write(matPond,0, matPond.length());
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				matPonderation.close();
			}
			catch(FileNotFoundException exc4){
				System.out.println("Error "+exc4.toString());
			}
			matPonderation.close();
		}
		

		if(matricePonderation.size()==0){
			System.out.println("No data found!\n*********** END ***************");
			System.exit(1);
		}
		
		
		matriceCnk = DDSamplingFunctions.matriceCnk(maxLength, minLength, M);
		double PreprocessingTime = System.currentTimeMillis() - start;
		System.out.println("Preprocessing time (s) : "+(PreprocessingTime/1000)+"\nTotal number of entities : "+matricePonderation.size());
		
		try {
			start = System.currentTimeMillis();
			List<Double> listRejet = new ArrayList<Double>();
			List<Double> coutComm = new ArrayList<Double>();
			for(int nb=1; nb<= 1; nb++) {
				new SampleRDF(matricePonderation, N, M,bdd, 1.0, utility, listRejet, coutComm, superClass);
			}
			Double moyRejet = 0.;
			Double ecartRejet = 0.;
			Double moyCout = 0.;
			Double ecartCout = 0.;
			boolean coolParam=true;
			if(coolParam) {
				moyRejet = DDSamplingFunctions.Moyenne(listRejet);
				ecartRejet = DDSamplingFunctions.EcartType(moyRejet,listRejet);
				moyCout = DDSamplingFunctions.Moyenne(coutComm);
				ecartCout = DDSamplingFunctions.EcartType(moyCout,coutComm);
			}
    		double SamplingTime = System.currentTimeMillis() - start;
			System.out.println("Sampling time (s) : "+(SamplingTime/1000));
			String out ="Cost of communication for sampling : "+moyCout+"�"+ecartCout+"\nRejetion rate : "+moyRejet+"�"+ecartRejet;
			System.out.println(out);
		} catch (IOException e) {
			System.out.println("Invalid input data.");
		}finally {
			System.out.println("*********** END ***************");
		}
	}

	public Integer getMatPondSize() {
		return matPondSize;
	}

	public void setMatPondSize(Integer matPondSize) {
		this.matPondSize = matPondSize;
	}

}
