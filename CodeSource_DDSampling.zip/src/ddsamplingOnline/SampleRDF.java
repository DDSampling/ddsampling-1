package ddsamplingOnline;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;


public class SampleRDF {

	public SampleRDF(Hashtable<String, List<BigDecimal>> matricePonderation, Integer N, Integer M, String bdd, double alpha, String utility, List<Double> listRejet, List<Double> coutComm, String superClass) throws IOException {
		String directory = "OutputRDFpatterns/";
		BufferedWriter printerAvecBuffer = null;
		List<BigDecimal> tabVal = new ArrayList<BigDecimal>();//BigDecimal[matricePonderation.size()];
		String[] tabKey = new String[matricePonderation.size()];
		Hashtable<String, List<BigDecimal>> crible=new Hashtable<String, List<BigDecimal>>();
		String endpointDBp="http://dbpedia.org/sparql";
		String endpointWD="https://query.wikidata.org/sparql";
		//String endpointYAGO="https://linkeddata1.calcul.u-psud.fr/sparql";
		
		Hashtable<Integer, List<String>> sample=new Hashtable<Integer, List<String>>();
		//******************
		/* util = "Freq" si on consid�re la fr�quence comme unitilit�
		 * util = "Aire" si on consid�re l'aire comme unitilit�
		 */
		String util = utility; // "Freq" ou "Aire" ou "Decay"
		//****************** 
		boolean bornee = true;
		//******************
		/*
		 * si util = "Aire" et bornee = true, alors on aura : u(area)*u(<=M)
		 * si util = "Freq" et bornee = true, alors on aura : u(<=M)
		 * si util = "Aire" et bornee = false, alors on aura : u(area)
		 * si util = "Freq" et bornee = false, alors on aura : u(freq)
		 */
		Integer tailleMin=1; //contrainte de taille minimale. 
							 //Mettez tailleMin=0 si vous d�sirez tirer l'ensemble vide
		//******************
		//******************
		//System.out.println(tabSizeOf.size());
		int norm,l=0;
		DDSamplingFunctions myFunctions = new DDSamplingFunctions();
		BigDecimal val= BigDecimal.ZERO;
		for(String instance:matricePonderation.keySet()) {
			norm = DDSamplingFunctions.sum(matricePonderation.get(instance)).intValue();
			List<BigDecimal> cribleS= myFunctions.phiBigDecimal(norm, tailleMin, M, util, bornee, alpha);
			crible.put(instance, cribleS);
			val=val.add(DDSamplingFunctions.sum(cribleS));
			tabVal.add(val);
			tabKey[l]=instance;
			l++;
		}
	
		BigDecimal sommeTotale = tabVal.get(tabVal.size()-1);
		
		Double nbRejet=0.0, nbItemAt=0.0;
		int iter=0;
		try{
			printerAvecBuffer = new BufferedWriter(
				new FileWriter(directory+"DBpedia_"+superClass+"_M"+M.toString()+"N"+N.toString()+".TXT", false));
			printerAvecBuffer.close();
		}
		catch(FileNotFoundException exc){
			//System.out.println("Erreur d'ecriture"+exc.toString());
		}
		for(Integer nbPatterns=0; nbPatterns<N; ){
			BigDecimal val1= DDSamplingFunctions.getRandomBigDecimal(sommeTotale);
			int k=0, j=matricePonderation.size();
			int indice=DDSamplingFunctions.findIndex(tabVal, k, j, val1);//  myFunctions.trouverBis(tabVal, k, j, val1);
			List<BigDecimal> cribleS = crible.get(tabKey[indice]);
			norm = DDSamplingFunctions.sum(matricePonderation.get(tabKey[indice])).intValue();
			List<Integer> listeIndices = myFunctions.sousEnsemble(cribleS, norm, tailleMin);
			//System.out.println(norm+" "+ listeIndices+" "+ tabKey[indice]);
			String endp = "";
			List<String> patternLis = new ArrayList<String>();
			String itemAt = "";
			boolean rejet = false;
			String pattern="";
			for(int b=0; b< listeIndices.size() && !rejet; b++){
				//System.out.println(listeIndices.toString()+";"+myFunctions.sum(matricePonderation.get(tabKey[indice])));
				List<BigDecimal> sizes = matricePonderation.get(tabKey[indice]);
				if(bdd.contains("D")) {
					if(bdd.contains("W")) {
						if(listeIndices.get(b)<sizes.get(0).intValue()) {
							itemAt = "select distinct ?p where {<http://dbpedia.org/resource/"+tabKey[indice].split(" ")[0]+"> ?p ?o "+
									"} LIMIT 1 OFFSET "+listeIndices.get(b);
							endp = endpointDBp;
							//System.out.println(tabKey[indice].split(" ")[0]+";"+listeIndices.get(b));
						}else {
							Integer indiceCorresp = listeIndices.get(b)-sizes.get(0).intValue();
							itemAt = "select distinct ?p where {"
									+ "<http://www.wikidata.org/entity/"+tabKey[indice].split(" ")[1]+"> ?p ?o"+
									//"  filter(<http://www.wikidata.org/prop/direct/P21> != ?p)"+  
								"} LIMIT 1 OFFSET "+indiceCorresp;
							endp = endpointWD;
							//System.out.println(tabKey[indice].split(" ")[1]+";"+indiceCorresp);
						}
					}
					else if(bdd.contains("D")){
						itemAt = "select distinct ?p where {<http://dbpedia.org/resource/"+tabKey[indice].split(" ")[0]+"> ?p ?o " +
								"} LIMIT 1 OFFSET "+listeIndices.get(b);
						endp = endpointDBp;
						//System.out.println(tabKey[indice].split(" ")[0]+";"+listeIndices.get(b));
					}
				}else if(bdd.contains("W")){
					itemAt = "select distinct ?p where {<http://www.wikidata.org/entity/"+tabKey[indice].split(" ")[1]+"> ?p ?o " +
							"} LIMIT 1 OFFSET "+listeIndices.get(b);
					endp = endpointWD;
					//System.out.println(tabKey[indice].split(" ")[0]+";"+listeIndices.get(b));
				}
	
				SparqlItemAt entity = new SparqlItemAt(itemAt,endp);
				if(entity.getItemAt()!=null) {
					pattern=pattern+entity.getItemAt()+" ";
					patternLis.add(entity.getItemAt());
				}else {
					rejet = true;
			        //System.out.println(tabKey[indice]+";"+entity.getItemAt()+";"+r+";"+endp);
			        //System.exit(1);
				}
				nbItemAt++;
			}
			if(rejet==false) {
				if(!sample.containsValue(patternLis)){
					sample.put(iter, patternLis);
					iter++;
				}
			    nbPatterns++;
				pattern=pattern+"\n";
			}else
				nbRejet++;
			//System.out.print(nbPatterns+" Nombre de rejet : "+nbRejet+" ; "+pattern);
			
			try{
				printerAvecBuffer = new BufferedWriter(
					new FileWriter(directory+"DBpedia_"+superClass+"_M"+M.toString()+"N"+N.toString()+".TXT", true));
					try {
						printerAvecBuffer.write(pattern,0, pattern.length());
					} catch (IOException e) {
						e.printStackTrace();
					}
					printerAvecBuffer.close();
			}
			catch(FileNotFoundException exc){
				System.out.println("Erreur d'ecriture"+exc.toString());
			}
		}
		//System.out.println("\t\tNumber of rejects : "+nbRejet);
		System.out.println("Please recover your sample from :\n"+directory+"DBpedia_"+superClass+"_M"+M.toString()+"N"+N.toString()+".TXT");
		//System.out.println("\tEnd Sampling.");
		listRejet.add(nbRejet);
		coutComm.add(nbItemAt);
		//System.exit(1);
		//System.out.println("*********** END ***************");
	}

}
