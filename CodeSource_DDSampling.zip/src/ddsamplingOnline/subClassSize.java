package ddsamplingOnline;
import java.util.Hashtable;

import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.ModelFactory;

public class subClassSize {
	Hashtable<String, Integer> subclassSize = new Hashtable<String, Integer>();

	public subClassSize(String supClass, String endpoint) {
		String queryString = 
            "SELECT * WHERE { "
    		+	"    SERVICE <" + endpoint + "> { "
			+	"		select ?c ?count where { "
			+	"			{ "
			+	"			   select ?c (count(distinct ?s) as ?count) where { "
			+	"			   		?s <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> ?c. "
			+	"			   		?c <http://www.w3.org/2000/01/rdf-schema#subClassOf> <http://dbpedia.org/ontology/"+supClass+">."
			+	"				} group by ?c "
			+	"			} "
			//+	"			filter(?count>="+minFreq.toString()+") "
			+	"		} "
			+   " }"
			+"}" ;
        Query query = QueryFactory.create(queryString) ;
        try (QueryExecution qexec = QueryExecutionFactory.create(query, ModelFactory.createDefaultModel())) {
        	ResultSet resultSet = qexec.execSelect() ;
            while (resultSet.hasNext()) {
				QuerySolution qs = resultSet.nextSolution();
				this.subclassSize.put(qs.getResource("c").toString(), qs.getLiteral("count").getInt());
			}
        }
	}

	
	public Hashtable<String, Integer> getSubClassSize() {
		return this.subclassSize;
	}
}



