package ddsamplingOnline;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Random;

public class DDSamplingFunctions {
	
	String echantillonToString(Hashtable<Integer, String> echantillon) {
		StringBuilder sb = new StringBuilder();
		
		Enumeration<?> e = echantillon.keys();
		while(e.hasMoreElements()){
			Object key = e.nextElement();
			sb.append(echantillon.get(key)+"\n");
		}	
		return sb.toString();
	}
	
	static Integer trouverBis(double[] tabVal, int i, int j, float x){
		int m=(i+j)/2;
		if(m==0 || (tabVal[m-1]<x && x<=tabVal[m]))
			return m;
		if(tabVal[m]<x)
			return trouverBis(tabVal,m+1,j,x);
		return trouverBis(tabVal,i,m,x);
	}
	
	//pile ou face
	boolean pile(){
		Random rn= new Random();
		return (rn.nextInt(2)==1);
	}
	
	
	
	public static BigDecimal combinaison(BigDecimal n, BigDecimal k){
		//Nombre de combinaisons de n objets pris k a k
		if(k.compareTo(n)==1 || n.doubleValue()==0) return BigDecimal.ZERO;
		if(k.compareTo(n.divide(new BigDecimal(2)))==1)
			k = n.subtract(k);
		BigDecimal x = BigDecimal.ONE;
		BigDecimal y = BigDecimal.ONE;
		BigDecimal i = n.subtract(k).add(BigDecimal.ONE);
		while(i.compareTo(n)<= 0){
			x = x.multiply(i).divide(y);
			y = y.add(BigDecimal.ONE);
			i = i.add(BigDecimal.ONE);
		}
		//print "x",x
		return x;
	}
	
	public static List<List<BigDecimal>> matriceCnk(int maxTransSize, int minTransSize, int maxk){
		maxk = Math.min(maxk, maxTransSize)+1;
		List<List<BigDecimal>> Cnk = new ArrayList<List<BigDecimal>>();
		for(int i=0; i<maxTransSize-minTransSize+1; i++) {
			List<BigDecimal> ligne = new ArrayList<BigDecimal>();
			for(int j=0; j<=maxk; j++) 
				ligne.add(combinaison(BigDecimal.valueOf(i+minTransSize), BigDecimal.valueOf(j)));
			Cnk.add(ligne);
		}
		return Cnk;
	}
	

	public static BigDecimal getRandomBigDecimal(BigDecimal max) {
        BigDecimal randFromDouble = new BigDecimal(Math.random());
        BigDecimal result = randFromDouble.multiply(max);
        //result = result.setScale(2, BigDecimal.ROUND_DOWN);
        return result;
    }
	
	public static int Ksize(List<BigDecimal> crible){
		List<BigDecimal> listElelm=new ArrayList<BigDecimal>();
		BigDecimal som=BigDecimal.ZERO;
		for(BigDecimal val:crible){
			som=som.add(val);
			listElelm.add(som);
		}
		
		int i=0, j=listElelm.size();
		int k=findIndex(listElelm,i,j,getRandomBigDecimal(som));
		return k+1;
	}

	public static int findIndex(List<BigDecimal> listVal, int i, int j, BigDecimal x){
		int m=(i+j)/2;
		//System.out.println(listVal+" "+i+" "+j+" "+x);
		if(m==0 || (listVal.get(m-1).compareTo(x)<0 && x.compareTo(listVal.get(m))<=0))
			return m;
		if(listVal.get(m).compareTo(x)<0)
			return findIndex(listVal,m+1,j,x);
		return findIndex(listVal,i,m,x);
	}
	
	public static BigDecimal sum(List<BigDecimal> crible){
		int i; BigDecimal som=BigDecimal.ZERO;
		for(i=0; i<crible.size();i++)
			som=som.add(crible.get(i));
		return som;
	}
			
	static Integer k_taille(double[] cribleS){
		double[] tab=new double[cribleS.length];
		int som=0;
		for(int i=0; i<cribleS.length; i++){
			som+=cribleS[i];
			tab[i]=som;
		}
		int i=0, j=tab.length;
		float alea= (float)(Math.random()*som);
		int k=trouverBis(tab,i,j,alea);
		return k+1;
	}
	
	String formatStrList(List<String> s, String sep){
		return s.toString().replace("[", "").replace("]", "").replace(",",sep);
	}
	
	public List<Integer> sousEnsemble(List<BigDecimal> cribleS,int norm, Integer m){
		Integer x=Ksize(cribleS)+Math.max(0, m-1); //Par d�faut m=1 pour toutes nos xp
		List<Integer>  T=new ArrayList<Integer>();
		int i;
		int indClass=-1; // indice de la classe, pas pris en compte dans cette impl�mentation
		for(i=0; i<norm; i++)
			if (i != indClass) T.add(i);
		List<Integer>  X=new ArrayList<Integer>();
		Random rn= new Random();
		for(i=0;i<x;i++){
			int l=rn.nextInt(T.size());
			X.add(T.get(l));
			T.remove(T.get(l));
		}		
		return X;
	}

	//Nombre de combinaisons de n objets pris k a k
	double combinaison(double n, double k){
		if(k>n || n==0) return 0;
		if(k > n/2)
			k = n-k;
		double x = 1;
		double y = 1;
		double i = n-k+1;
		while(i <= n){
			x = (x*i)/y;
			y += 1;
			i += 1;
		}
		return x;
	}

	
	public int sum(double[] cribleS){
		int som=0,i;
		for(i=0; i<cribleS.length;i++)
			som+=cribleS[i];
		return som;
	}
	
	//Nombre de sous-ensembles d'un itemset suivant une fonction d'utilit�
	double[] phi(int tailleItemset, int m, int M, String util, boolean bornee, double alpha){
		if(M==0 || tailleItemset==0 || m>M){
			double[] Tab={0};
			return Tab;
		}
		int k;
		if(bornee)
			k=Math.min(M,tailleItemset);
		else
			k=tailleItemset;
		double[] Tab= new double[k-m+1];
		if(util.equals("Area"))
			for (int i=m, j=0; i<=k; i++, j++)
				Tab[j]=(int) combinaison(tailleItemset,i)*i;
		else if(util.equals("Freq"))
			for (int i=m, j=0; i<=k; i++, j++)
				Tab[j]=(int) combinaison(tailleItemset,i);
		else if(util.equals("Decay"))
			for (int i=m, j=0; i<=k; i++, j++)
				Tab[j]=(int) combinaison(tailleItemset,i)*Math.pow(alpha, i);
		else {
			System.out.println("Be sure to specify the input parameters, please.");
			System.exit(0);			
		}
		return Tab;
	}
	
	List<BigDecimal> phiBigDecimal(int tailleItemset, int m, int M, String util, boolean bornee, double alpha){
		List<BigDecimal> crible = new ArrayList<BigDecimal>();
		if(M==0 || tailleItemset==0 || m>M){
			crible.add(BigDecimal.ZERO);
			return crible;
		}
		int k;
		if(bornee)
			k=Math.min(M,tailleItemset);
		else
			k=tailleItemset;
		if(util.equals("Area"))
			for (int i=m, j=0; i<=k; i++, j++)
				crible.add(DDSamplingRDF.matriceCnk.get(tailleItemset).get(j).multiply(BigDecimal.valueOf(i)));
		else if(util.equals("Freq"))
			for (int i=m, j=0; i<=k; i++, j++)
				crible.add(DDSamplingRDF.matriceCnk.get(tailleItemset).get(j));
		else if(util.equals("Decay"))
			for (int i=m, j=0; i<=k; i++, j++)
				crible.add(DDSamplingRDF.matriceCnk.get(tailleItemset).get(j).multiply(BigDecimal.valueOf(Math.pow(alpha, i))));
		else {
			System.out.println("Be sure to specify the input parameters, please.");
			System.exit(0);			
		}
		return crible;
	}
	
	//Moyenne
	static double Moyenne(List<Double> arrayCoutCom) {
		double meanSum=0;
		for (int i = 0; i < arrayCoutCom.size(); i++) 
			meanSum += arrayCoutCom.get(i); 
	    return (double)meanSum/arrayCoutCom.size(); 
	}
	
	//Ecart-type
	static double EcartType(double mean, List<Double> arrayCoutCom) {
		double deviationSum=0;
		double arrayVar[] = new double[arrayCoutCom.size()];
	    for (int i = 0; i < arrayCoutCom.size(); i++) 
	    	arrayVar[i] = (Math.pow((arrayCoutCom.get(i) - mean), 2)); 
	    for (int i = 0; i < arrayCoutCom.size(); i++) 
	    	deviationSum += arrayVar[i]; 
	    double variance = ((deviationSum/arrayCoutCom.size())); 
	    return ((int)(Math.sqrt(variance)*100))/100.; 
	}
}
