package ddsamplingOnline;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.ModelFactory;

public class SparqlItemAt{
	private String itemAt;
	public SparqlItemAt(String r, String endpoint) {
		String queryString = 
            "SELECT * WHERE { "
    		+	"    SERVICE <" + endpoint + "> { "+
			    		r
			+		"}"
			+"}" ;
        Query query = QueryFactory.create(queryString) ;
        try (QueryExecution qexec = QueryExecutionFactory.create(query, ModelFactory.createDefaultModel())) {
        	if (qexec != null) {
	        	ResultSet resultSet = qexec.execSelect() ;
	            //ResultSetFormatter.out(System.out, resultSet, query) ;
	        	if (resultSet != null)
		            while (resultSet.hasNext()) {
						QuerySolution qs = resultSet.nextSolution();
						if (qs != null)
						itemAt = qs.getResource("p").toString();
					}
        	}
        }catch(Exception e) {}
	}

	public String getItemAt() {
		//System.out.println(this.itemAt);
		return itemAt;
	}
}
/*
import org.apache.jena.query.QuerySolution;

public class SparqlItemAt extends SparqlQuerier{
	
	private String itemAt;

	public SparqlItemAt(String r, String endpoint) {
		super(r, endpoint);
	}

	@Override
	public void begin() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void end() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean fact(QuerySolution qs) throws InterruptedException {
		this.itemAt = qs.getResource("p").toString();
		return true; 
	}
	
	String getItemAt() {
		System.out.println(this.itemAt);
		return this.itemAt;
	}
}
*/