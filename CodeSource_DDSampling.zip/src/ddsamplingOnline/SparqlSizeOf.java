package ddsamplingOnline;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.jena.query.QuerySolution;

public class SparqlSizeOf extends SparqlQuerier{
	
	public SparqlSizeOf(String r, String endpoint) {
		super(r, endpoint);
	}

	@Override
	public void begin() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void end() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean fact(QuerySolution qs) throws InterruptedException {
		String entity = qs.getResource("s").toString().replace("http://dbpedia.org/resource/", "");
		Integer  size = qs.getLiteral("count").getInt();
		String[] wiki = qs.getResource("l").toString().split("/");
		List<BigDecimal> values = new ArrayList<BigDecimal>();
		values.add(new BigDecimal(size));			
		DDSamplingRDF.matricePonderation.put(entity+" "+wiki[wiki.length-1], values);
		DDSamplingRDF.requeteWiki = DDSamplingRDF.requeteWiki+" (<http://www.wikidata.org/entity/"+wiki[wiki.length-1]+">)";
		DDSamplingRDF.keyRequetWiki.put(wiki[wiki.length-1], entity+" "+wiki[wiki.length-1]);
		//System.out.println(DDSamplingRDF.requeteWiki);
		return true; 
	}

	/*
	public Integer som(Hashtable<String, Integer> matricePond) {
		Integer som=0;
		for(String key:matricePond.keySet()) som+=matricePond.get(key);
		return som;
	}
	
	public Integer max(Hashtable<String, Integer> matricePond) {
		Integer x=0;
		for(String key:matricePond.keySet()) x=Math.max(x, matricePond.get(key));
		return x;
	}
	
	public Integer min(Hashtable<String, Integer> matricePond) {
		Integer x=1;
		for(String key:matricePond.keySet()) x=Math.min(x, matricePond.get(key));
		return x;
	}*/

}
