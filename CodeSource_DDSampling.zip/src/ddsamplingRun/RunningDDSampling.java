package ddsamplingRun;

/**
 * 
 * @author ldiop
 *
 */


import java.util.Hashtable;


public class RunningDDSampling {

	public static void main(String[] args) throws NumberFormatException, Exception {
		boolean defautlParam=false;

		Hashtable<String, String> myArgs = new Hashtable<String, String>();
		myArgs.put("online", "no");
		myArgs.put("sampleSize", "100");
		myArgs.put("utility", "Freq");
		myArgs.put("dataset", "connect");
		myArgs.put("maxLength", "3");
		myArgs.put("pType", "VL");
		myArgs.put("nbSites", "10");
		myArgs.put("nbFailedSites", "0");
		myArgs.put("errorRate", "0.0");
		myArgs.put("recordSample", "No");

		for(String arg:args) {
			String[] val=arg.split(":");
			myArgs.put(val[0], val[1]);
		}
		
		String online=myArgs.get("online");
		if(online==null) {
			System.out.println("Specify the location data : local or on line?");
			System.exit(1);
		}

		Integer nbRep=1;
		
		try {
			nbRep = Integer.parseInt(myArgs.get("nbRep"));
		}catch(Exception e) {
			nbRep=1;
		}
		myArgs.remove("online");
		myArgs.remove("nbRep");
		
		if(myArgs.size()==0)
			defautlParam=true;
		
		for(int i=0; i<nbRep; i++) {
			if(online.toLowerCase().equals("no")) {
				new ddsamplingLocal.DDSamplingLocal(myArgs,defautlParam);
			}
			else {
				new ddsamplingOnline.DDSamplingRDF(myArgs, defautlParam);
			}
		}
		//System.out.println("Sampling with DDSampling successfully succeeded.");
	}

}
